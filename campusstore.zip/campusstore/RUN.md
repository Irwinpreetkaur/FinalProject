# RUN.md

Java version: Java 17

Database: MySQL. The database schema is auto-created by Hibernate using `spring.jpa.hibernate.ddl-auto=update`.

Database credentials are set in:
`src/main/resources/application.properties`

Start command:
`.\mvnw.cmd spring-boot:run`

Admin login:
Email: `admin@example.com`
Password: `Admin123!`

The admin account is created automatically at startup by `DataInitializer` if it does not already exist.

Customer login:
Use the Register page to create a new customer account, then log in with that email and password.

Seed data:
At startup, the app seeds 3 categories and 7 products if the catalog tables are empty, so the catalog is immediately usable and pagination can be demonstrated.

Security note:
CSRF is disabled for this project configuration.