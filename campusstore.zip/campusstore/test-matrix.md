# Test Matrix

| ID  | Scenario | Steps | Expected Result | Actual Result |
|-----|---------|------|----------------|--------------|
| T01 | Admin login | Log in using admin@example.com / Admin123! and open /admin | Admin dashboard loads successfully | Logged in as admin and opened /admin dashboard showing categories, products, and orders |
| T02 | Admin creates category | Enter category name and click "Create Category" | Category is saved and appears in category list | Created category successfully and it appeared in categories table |
| T03 | Admin product lifecycle | Create product → edit product → deactivate product | Product appears in catalog when active and disappears when deactivated | Created product, edited price and stock, then deactivated it. Product no longer appears in catalog page |
| T04 | Customer registration | Open /register and create new user with email Irwin@example.com | User account created and redirected to login page | Customer registered successfully and was redirected to login |
| T05 | Catalog Filter / Sort / Pagination | Use filter by name, change sorting and navigate pages | Catalog updates results correctly | Default page shows 5 products. Sorting by price works. Page 1 shows remaining products |
| T06 | Create multi-item order | Customer selects Notebook qty 2 and Pen qty 3 and submits order | Order confirmation page shows order ID and total | Order placed successfully. Redirected to confirmation page with Order ID = 1 and Total = 14.45 |
| T07 | Stock deducted + totals correct | After placing order check product stock and order total | Stock reduced and total computed server-side | Notebook stock changed 25 → 23 and Pen stock changed 50 → 47. Total stored as 14.45 |
| T08 | My order history + details | Open /my-orders and click order details | Customer sees their own order items and totals | Order list shows Order ID 1 and details page shows Notebook qty 2 and Pen qty 3 |
| T09 | Forbidden — wrong role | Log in as CUSTOMER and try to open /admin | Access blocked with Forbidden page | Customer attempted to open /admin and received 403 Forbidden page |
| T10 | Forbidden — wrong owner | Customer A attempts to open another customer order URL | Access blocked with Forbidden page | Attempted to open /my-orders/{otherOrderId} and received Forbidden message |
| T11 | Admin status update + cancel restores stock | Admin changes order NEW → CANCELLED | Order status updated and stock restored | Order changed NEW → CANCELLED. Notebook stock restored 23 → 25 and Pen stock restored 47 → 50 |