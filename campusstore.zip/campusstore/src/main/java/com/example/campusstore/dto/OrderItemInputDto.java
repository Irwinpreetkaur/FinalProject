package com.example.campusstore.dto;

public class OrderItemInputDto {

    private Long productId;
    private Integer qty;

    public OrderItemInputDto() {
    }

    public Long getProductId() {
        return productId;
    }

    public Integer getQty() {
        return qty;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }
}