package com.example.campusstore.dto;

import java.util.ArrayList;
import java.util.List;

public class CreateOrderRequest {

    private List<OrderItemInputDto> items = new ArrayList<>();

    public CreateOrderRequest() {
    }

    public List<OrderItemInputDto> getItems() {
        return items;
    }

    public void setItems(List<OrderItemInputDto> items) {
        this.items = items;
    }
}