package com.example.campusstore.config;

import java.math.BigDecimal;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.example.campusstore.entity.Category;
import com.example.campusstore.entity.Product;
import com.example.campusstore.entity.Role;
import com.example.campusstore.entity.User;
import com.example.campusstore.repository.CategoryRepository;
import com.example.campusstore.repository.ProductRepository;
import com.example.campusstore.repository.UserRepository;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final ProductRepository productRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository,
                           CategoryRepository categoryRepository,
                           ProductRepository productRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.categoryRepository = categoryRepository;
        this.productRepository = productRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        seedAdmin();
        seedCatalogData();
    }

    private void seedAdmin() {
        if (!userRepository.existsByEmail("admin@example.com")) {
            User admin = new User();
            admin.setName("Admin");
            admin.setEmail("admin@example.com");
            admin.setPasswordHash(passwordEncoder.encode("Admin123!"));
            admin.setRole(Role.ADMIN);

            userRepository.save(admin);

            System.out.println("Admin user created: admin@example.com / Admin123!");
        }
    }

    private void seedCatalogData() {
        if (categoryRepository.count() == 0 && productRepository.count() == 0) {
            Category stationery = new Category();
            stationery.setName("Stationery");
            categoryRepository.save(stationery);

            Category electronics = new Category();
            electronics.setName("Electronics");
            categoryRepository.save(electronics);

            Category clothing = new Category();
            clothing.setName("Clothing");
            categoryRepository.save(clothing);

            saveProduct("Notebook", "200-page ruled notebook", new BigDecimal("4.99"), 25, true, stationery);
            saveProduct("Pen", "Blue ink ball pen", new BigDecimal("1.49"), 50, true, stationery);
            saveProduct("Marker", "Permanent black marker", new BigDecimal("2.99"), 30, true, stationery);
            saveProduct("USB Drive", "32GB USB 3.0 flash drive", new BigDecimal("12.99"), 20, true, electronics);
            saveProduct("Calculator", "Scientific calculator", new BigDecimal("24.99"), 10, true, electronics);
            saveProduct("Campus Hoodie", "Grey campus hoodie", new BigDecimal("39.99"), 12, true, clothing);
            saveProduct("Water Bottle", "Reusable steel water bottle", new BigDecimal("14.99"), 18, true, clothing);

            System.out.println("Sample categories and products created.");
        }
    }

    private void saveProduct(String name, String description, BigDecimal price,
                             Integer stockQty, Boolean isActive, Category category) {
        Product product = new Product();
        product.setName(name);
        product.setDescription(description);
        product.setPrice(price);
        product.setStockQty(stockQty);
        product.setIsActive(isActive);
        product.setCategory(category);

        productRepository.save(product);
    }
}