package com.example.campusstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.campusstore.entity.OrderItem;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {
}