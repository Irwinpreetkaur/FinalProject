package com.example.campusstore.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.campusstore.entity.Product;
import com.example.campusstore.repository.ProductRepository;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public Page<Product> searchProducts(
            String name,
            Long categoryId,
            Boolean inStock,
            int page,
            int size,
            String sortBy,
            String sortDir
    ) {
        Sort sort = sortDir.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();

        Pageable pageable = PageRequest.of(page, size, sort);

        boolean hasName = name != null && !name.trim().isEmpty();
        boolean hasCategory = categoryId != null;
        boolean hasInStock = inStock != null && inStock;

        if (hasName && hasCategory && hasInStock) {
            return productRepository.findByIsActiveTrueAndNameContainingIgnoreCaseAndCategoryIdAndStockQtyGreaterThan(
                    name, categoryId, 0, pageable
            );
        }

        if (hasName && hasCategory) {
            return productRepository.findByIsActiveTrueAndNameContainingIgnoreCaseAndCategoryId(
                    name, categoryId, pageable
            );
        }

        if (hasName && hasInStock) {
            return productRepository.findByIsActiveTrueAndNameContainingIgnoreCaseAndStockQtyGreaterThan(
                    name, 0, pageable
            );
        }

        if (hasCategory && hasInStock) {
            return productRepository.findByIsActiveTrueAndCategoryIdAndStockQtyGreaterThan(
                    categoryId, 0, pageable
            );
        }

        if (hasName) {
            return productRepository.findByIsActiveTrueAndNameContainingIgnoreCase(name, pageable);
        }

        if (hasCategory) {
            return productRepository.findByIsActiveTrueAndCategoryId(categoryId, pageable);
        }

        if (hasInStock) {
            return productRepository.findByIsActiveTrueAndStockQtyGreaterThan(0, pageable);
        }

        return productRepository.findByIsActiveTrue(pageable);
    }

    public java.util.List<Product> getAllProducts() {
    return productRepository.findAll();
}

    public List<Product> getActiveProducts() {
        return productRepository.findByIsActiveTrue();
    }

    public Product getProductById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new com.example.campusstore.exception.NotFoundException("Product not found"));
    }

    public void createProduct(com.example.campusstore.dto.ProductFormDto dto,
                          com.example.campusstore.repository.CategoryRepository categoryRepository) {

    if (dto.getName() == null || dto.getName().trim().isEmpty()) {
        throw new RuntimeException("Product name is required");
    }

    if (dto.getPrice() == null || dto.getPrice().compareTo(java.math.BigDecimal.ZERO) < 0) {
        throw new RuntimeException("Price must be 0 or more");
    }

    if (dto.getStockQty() == null || dto.getStockQty() < 0) {
        throw new RuntimeException("Stock must be 0 or more");
    }

    com.example.campusstore.entity.Category category = categoryRepository.findById(dto.getCategoryId())
            .orElseThrow(() -> new RuntimeException("Category not found"));

    Product product = new Product();
    product.setName(dto.getName().trim());
    product.setDescription(dto.getDescription());
    product.setPrice(dto.getPrice());
    product.setStockQty(dto.getStockQty());
    product.setIsActive(true);
    product.setCategory(category);

    productRepository.save(product);
}

public Product getById(Long id) {
    return productRepository.findById(id)
            .orElseThrow(() -> new com.example.campusstore.exception.NotFoundException("Product not found"));
}

public void updateProduct(com.example.campusstore.dto.ProductFormDto dto,
                          Long productId,
                          com.example.campusstore.repository.CategoryRepository categoryRepository) {

    Product product = productRepository.findById(productId)
            .orElseThrow(() -> new RuntimeException("Product not found"));

    if (dto.getName() == null || dto.getName().trim().isEmpty()) {
        throw new RuntimeException("Product name is required");
    }

    if (dto.getPrice() == null || dto.getPrice().compareTo(java.math.BigDecimal.ZERO) < 0) {
        throw new RuntimeException("Price must be 0 or more");
    }

    if (dto.getStockQty() == null || dto.getStockQty() < 0) {
        throw new RuntimeException("Stock must be 0 or more");
    }

    com.example.campusstore.entity.Category category = categoryRepository.findById(dto.getCategoryId())
            .orElseThrow(() -> new RuntimeException("Category not found"));

    product.setName(dto.getName().trim());
    product.setDescription(dto.getDescription());
    product.setPrice(dto.getPrice());
    product.setStockQty(dto.getStockQty());
    product.setCategory(category);

    productRepository.save(product);
}

public void deactivateProduct(Long productId) {
    Product product = productRepository.findById(productId)
            .orElseThrow(() -> new RuntimeException("Product not found"));

    product.setIsActive(false);
    productRepository.save(product);
}
}

