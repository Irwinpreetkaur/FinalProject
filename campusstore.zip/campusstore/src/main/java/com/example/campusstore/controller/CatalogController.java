package com.example.campusstore.controller;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.campusstore.entity.Product;
import com.example.campusstore.repository.CategoryRepository;
import com.example.campusstore.service.ProductService;

@Controller
public class CatalogController {

    private final ProductService productService;
    private final CategoryRepository categoryRepository;

    public CatalogController(ProductService productService, CategoryRepository categoryRepository) {
        this.productService = productService;
        this.categoryRepository = categoryRepository;
    }

    @GetMapping("/catalog")
    public String catalogPage(
            @RequestParam(defaultValue = "") String name,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) Boolean inStock,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(defaultValue = "name") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir,
            Model model
    ) {
        Page<Product> productPage = productService.searchProducts(
                name, categoryId, inStock, page, size, sortBy, sortDir
        );

        model.addAttribute("productPage", productPage);
        model.addAttribute("products", productPage.getContent());
        model.addAttribute("categories", categoryRepository.findAll());

        model.addAttribute("name", name);
        model.addAttribute("categoryId", categoryId);
        model.addAttribute("inStock", inStock);
        model.addAttribute("page", page);
        model.addAttribute("size", size);
        model.addAttribute("sortBy", sortBy);
        model.addAttribute("sortDir", sortDir);

        return "catalog";
    }

    @GetMapping("/products/{id}")
    public String productDetailsPage(@PathVariable Long id, Model model) {
        model.addAttribute("product", productService.getProductById(id));
        return "product-details";
    }
}