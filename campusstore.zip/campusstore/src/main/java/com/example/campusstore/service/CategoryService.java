package com.example.campusstore.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.campusstore.entity.Category;
import com.example.campusstore.repository.CategoryRepository;

@Service
public class CategoryService {

    private final CategoryRepository categoryRepository;

    public CategoryService(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    public void createCategory(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new RuntimeException("Category name is required");
        }

        if (categoryRepository.existsByNameIgnoreCase(name.trim())) {
            throw new RuntimeException("Category already exists");
        }

        Category category = new Category();
        category.setName(name.trim());
        categoryRepository.save(category);
    }
}