package com.example.campusstore.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.campusstore.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {

    List<Product> findByIsActiveTrue();

    Page<Product> findByIsActiveTrue(Pageable pageable);

    Page<Product> findByIsActiveTrueAndNameContainingIgnoreCase(String name, Pageable pageable);

    Page<Product> findByIsActiveTrueAndCategoryId(Long categoryId, Pageable pageable);

    Page<Product> findByIsActiveTrueAndStockQtyGreaterThan(Integer stockQty, Pageable pageable);

    Page<Product> findByIsActiveTrueAndNameContainingIgnoreCaseAndCategoryId(
            String name, Long categoryId, Pageable pageable
    );

    Page<Product> findByIsActiveTrueAndNameContainingIgnoreCaseAndStockQtyGreaterThan(
            String name, Integer stockQty, Pageable pageable
    );

    Page<Product> findByIsActiveTrueAndCategoryIdAndStockQtyGreaterThan(
            Long categoryId, Integer stockQty, Pageable pageable
    );

    Page<Product> findByIsActiveTrueAndNameContainingIgnoreCaseAndCategoryIdAndStockQtyGreaterThan(
            String name, Long categoryId, Integer stockQty, Pageable pageable
    );
}