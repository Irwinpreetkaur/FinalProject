package com.example.campusstore.dto;

import java.math.BigDecimal;

public class ProductFormDto {

    private String name;
    private String description;
    private BigDecimal price;
    private Integer stockQty;
    private Long categoryId;

    public ProductFormDto() {
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public Integer getStockQty() {
        return stockQty;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public void setStockQty(Integer stockQty) {
        this.stockQty = stockQty;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }
}