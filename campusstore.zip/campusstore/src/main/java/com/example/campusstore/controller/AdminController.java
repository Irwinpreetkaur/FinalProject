package com.example.campusstore.controller;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.campusstore.dto.ProductFormDto;
import com.example.campusstore.entity.CustomerOrder;
import com.example.campusstore.entity.OrderStatus;
import com.example.campusstore.entity.Product;
import com.example.campusstore.repository.CategoryRepository;
import com.example.campusstore.service.CategoryService;
import com.example.campusstore.service.OrderService;
import com.example.campusstore.service.ProductService;

@Controller
public class AdminController {

    private final CategoryService categoryService;
    private final ProductService productService;
    private final CategoryRepository categoryRepository;
    private final OrderService orderService;

    public AdminController(CategoryService categoryService,
                           ProductService productService,
                           CategoryRepository categoryRepository,
                           OrderService orderService) {
        this.categoryService = categoryService;
        this.productService = productService;
        this.categoryRepository = categoryRepository;
        this.orderService = orderService;
    }

    @GetMapping("/admin")
    public String adminPage(@RequestParam(defaultValue = "0") int page,
                            @RequestParam(defaultValue = "5") int size,
                            Model model) {
        Page<CustomerOrder> orderPage = orderService.getAllOrders(page, size);

        model.addAttribute("categories", categoryService.getAllCategories());
        model.addAttribute("products", productService.getAllProducts());
        model.addAttribute("productForm", new ProductFormDto());
        model.addAttribute("orderPage", orderPage);
        model.addAttribute("orders", orderPage.getContent());
        model.addAttribute("page", page);
        model.addAttribute("size", size);
        model.addAttribute("statuses", OrderStatus.values());

        return "admin-dashboard";
    }

    @PostMapping("/admin/categories")
    public String createCategory(String name, RedirectAttributes redirectAttributes) {
        try {
            categoryService.createCategory(name);
            redirectAttributes.addFlashAttribute("successMessage", "Category created");
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }
        return "redirect:/admin";
    }

    @PostMapping("/admin/products")
    public String createProduct(@ModelAttribute("productForm") ProductFormDto productForm,
                                RedirectAttributes redirectAttributes) {
        try {
            productService.createProduct(productForm, categoryRepository);
            redirectAttributes.addFlashAttribute("successMessage", "Product created");
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }
        return "redirect:/admin";
    }

    @GetMapping("/admin/products/{id}/edit")
    public String editProductPage(@PathVariable Long id, Model model) {
        Product product = productService.getById(id);

        ProductFormDto productForm = new ProductFormDto();
        productForm.setName(product.getName());
        productForm.setDescription(product.getDescription());
        productForm.setPrice(product.getPrice());
        productForm.setStockQty(product.getStockQty());
        productForm.setCategoryId(product.getCategory().getId());

        model.addAttribute("productId", id);
        model.addAttribute("productForm", productForm);
        model.addAttribute("categories", categoryService.getAllCategories());

        return "product-edit";
    }

    @PostMapping("/admin/products/{id}/edit")
    public String updateProduct(@PathVariable Long id,
                                @ModelAttribute("productForm") ProductFormDto productForm,
                                RedirectAttributes redirectAttributes) {
        try {
            productService.updateProduct(productForm, id, categoryRepository);
            redirectAttributes.addFlashAttribute("successMessage", "Product updated");
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }
        return "redirect:/admin";
    }

    @PostMapping("/admin/products/{id}/deactivate")
    public String deactivateProduct(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            productService.deactivateProduct(id);
            redirectAttributes.addFlashAttribute("successMessage", "Product deactivated");
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }
        return "redirect:/admin";
    }

    @PostMapping("/admin/orders/{id}/status")
    public String updateOrderStatus(@PathVariable Long id,
                                    @RequestParam OrderStatus status,
                                    RedirectAttributes redirectAttributes) {
        try {
            orderService.updateOrderStatus(id, status);
            redirectAttributes.addFlashAttribute("successMessage", "Order status updated");
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }
        return "redirect:/admin";
    }
}