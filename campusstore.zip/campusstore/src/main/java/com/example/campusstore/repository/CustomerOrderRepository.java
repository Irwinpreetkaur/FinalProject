package com.example.campusstore.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.campusstore.entity.CustomerOrder;
import com.example.campusstore.entity.User;

public interface CustomerOrderRepository extends JpaRepository<CustomerOrder, Long> {

    Page<CustomerOrder> findByCustomer(User customer, Pageable pageable);

    Optional<CustomerOrder> findByIdAndCustomer(Long id, User customer);
}