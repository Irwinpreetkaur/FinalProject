package com.example.campusstore.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.campusstore.dto.CreateOrderRequest;
import com.example.campusstore.dto.OrderItemInputDto;
import com.example.campusstore.entity.CustomerOrder;
import com.example.campusstore.entity.Product;
import com.example.campusstore.service.OrderService;
import com.example.campusstore.service.ProductService;

@Controller
public class OrderController {

    private final ProductService productService;
    private final OrderService orderService;

    public OrderController(ProductService productService, OrderService orderService) {
        this.productService = productService;
        this.orderService = orderService;
    }

    @GetMapping("/orders/create")
    public String createOrderPage(Model model) {
        List<Product> products = productService.getActiveProducts();

        CreateOrderRequest createOrderRequest = new CreateOrderRequest();
        for (Product product : products) {
            OrderItemInputDto item = new OrderItemInputDto();
            item.setProductId(product.getId());
            item.setQty(0);
            createOrderRequest.getItems().add(item);
        }

        model.addAttribute("products", products);
        model.addAttribute("createOrderRequest", createOrderRequest);

        return "order-create";
    }

    @PostMapping("/orders")
    public String placeOrder(
            @ModelAttribute CreateOrderRequest createOrderRequest,
            Authentication authentication,
            RedirectAttributes redirectAttributes
    ) {
        try {
            CustomerOrder order = orderService.createOrder(authentication.getName(), createOrderRequest);
            return "redirect:/orders/confirmation/" + order.getId();
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
            return "redirect:/orders/create";
        }
    }

    @GetMapping("/orders/confirmation/{id}")
    public String orderConfirmationPage(@PathVariable Long id, Authentication authentication, Model model) {
        CustomerOrder order = orderService.getMyOrder(authentication.getName(), id);
        model.addAttribute("order", order);
        return "order-confirmation";
    }

    @GetMapping("/my-orders")
    public String myOrdersPage(
            Authentication authentication,
            @org.springframework.web.bind.annotation.RequestParam(defaultValue = "0") int page,
            @org.springframework.web.bind.annotation.RequestParam(defaultValue = "5") int size,
            Model model
    ) {
        Page<CustomerOrder> orderPage = orderService.getMyOrders(authentication.getName(), page, size);

        model.addAttribute("orderPage", orderPage);
        model.addAttribute("orders", orderPage.getContent());
        model.addAttribute("page", page);
        model.addAttribute("size", size);

        return "my-orders";
    }

    @GetMapping("/my-orders/{id}")
    public String myOrderDetailsPage(@PathVariable Long id, Authentication authentication, Model model) {
        CustomerOrder order = orderService.getMyOrder(authentication.getName(), id);
        model.addAttribute("order", order);
        return "order-details";
    }
}