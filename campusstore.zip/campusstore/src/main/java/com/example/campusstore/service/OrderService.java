package com.example.campusstore.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.campusstore.dto.CreateOrderRequest;
import com.example.campusstore.dto.OrderItemInputDto;
import com.example.campusstore.entity.CustomerOrder;
import com.example.campusstore.entity.OrderItem;
import com.example.campusstore.entity.OrderStatus;
import com.example.campusstore.entity.Product;
import com.example.campusstore.entity.User;
import com.example.campusstore.repository.CustomerOrderRepository;
import com.example.campusstore.repository.ProductRepository;
import com.example.campusstore.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class OrderService {

    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    private final CustomerOrderRepository customerOrderRepository;

    public OrderService(UserRepository userRepository,
                        ProductRepository productRepository,
                        CustomerOrderRepository customerOrderRepository) {
        this.userRepository = userRepository;
        this.productRepository = productRepository;
        this.customerOrderRepository = customerOrderRepository;
    }

    @Transactional
    public CustomerOrder createOrder(String customerEmail, CreateOrderRequest request) {
        User customer = userRepository.findByEmail(customerEmail)
                .orElseThrow(() -> new com.example.campusstore.exception.NotFoundException("Customer not found"));

        if (request == null || request.getItems() == null || request.getItems().isEmpty()) {
            throw new RuntimeException("No items submitted");
        }

        List<OrderItemInputDto> selectedItems = request.getItems().stream()
                .filter(item -> item.getQty() != null && item.getQty() > 0)
                .toList();

        if (selectedItems.size() < 2) {
            throw new RuntimeException("Please select at least 2 different products");
        }

        CustomerOrder order = new CustomerOrder();
        order.setCustomer(customer);
        order.setCreatedAt(LocalDateTime.now());
        order.setStatus(OrderStatus.NEW);

        List<OrderItem> orderItems = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;

        for (OrderItemInputDto input : selectedItems) {
            Product product = productRepository.findById(input.getProductId())
                    .orElseThrow(() -> new RuntimeException("Product not found"));

            if (!Boolean.TRUE.equals(product.getIsActive())) {
                throw new RuntimeException("Inactive product cannot be ordered: " + product.getName());
            }

            if (input.getQty() <= 0) {
                throw new RuntimeException("Quantity must be greater than zero");
            }

            if (product.getStockQty() < input.getQty()) {
                throw new RuntimeException("Not enough stock for product: " + product.getName());
            }

            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(order);
            orderItem.setProduct(product);
            orderItem.setQty(input.getQty());
            orderItem.setUnitPrice(product.getPrice());

            orderItems.add(orderItem);

            BigDecimal lineTotal = product.getPrice().multiply(BigDecimal.valueOf(input.getQty()));
            total = total.add(lineTotal);

            product.setStockQty(product.getStockQty() - input.getQty());
        }

        order.setItems(orderItems);
        order.setTotal(total);

        return customerOrderRepository.save(order);
    }

    public Page<CustomerOrder> getMyOrders(String customerEmail, int page, int size) {
        User customer = userRepository.findByEmail(customerEmail)
                .orElseThrow(() -> new com.example.campusstore.exception.NotFoundException("Customer not found"));

        return customerOrderRepository.findByCustomer(customer, PageRequest.of(page, size));
    }

    public CustomerOrder getMyOrder(String customerEmail, Long orderId) {
        User customer = userRepository.findByEmail(customerEmail)
                .orElseThrow(() -> new com.example.campusstore.exception.NotFoundException("Customer not found"));

        return customerOrderRepository.findByIdAndCustomer(orderId, customer)
                .orElseThrow(() -> new com.example.campusstore.exception.ForbiddenException("You cannot view this order"));
    }

    public org.springframework.data.domain.Page<CustomerOrder> getAllOrders(int page, int size) {
    return customerOrderRepository.findAll(org.springframework.data.domain.PageRequest.of(page, size));
}

@jakarta.transaction.Transactional
public void updateOrderStatus(Long orderId, OrderStatus newStatus) {
    CustomerOrder order = customerOrderRepository.findById(orderId)
            .orElseThrow(() -> new com.example.campusstore.exception.NotFoundException("Order not found"));

    if (order.getStatus() == OrderStatus.FULFILLED || order.getStatus() == OrderStatus.CANCELLED) {
        throw new RuntimeException("Terminal orders cannot be changed");
    }

    if (order.getStatus() != OrderStatus.NEW) {
        throw new RuntimeException("Only NEW orders can be updated");
    }

    if (newStatus != OrderStatus.FULFILLED && newStatus != OrderStatus.CANCELLED) {
        throw new RuntimeException("Invalid status transition");
    }

    if (newStatus == OrderStatus.CANCELLED) {
        for (OrderItem item : order.getItems()) {
            Product product = item.getProduct();
            product.setStockQty(product.getStockQty() + item.getQty());
        }
    }

    order.setStatus(newStatus);
    customerOrderRepository.save(order);
}
}